(() => {
  const STORES = { zwe: 'Zweibrücken', tri: 'Trier' }, s = new URLSearchParams(location.search).get('s'), id = STORES[s] ? s : 'zwe';
  const url = new URL('./?s=' + id, location.href).href;
  new QRCode(document.getElementById('qr'), { text: url, width: 600, height: 600, colorDark: '#233023', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
  document.getElementById('store').textContent = 'dean & david ' + STORES[id]; document.getElementById('url').textContent = url;
  document.getElementById('print').onclick = () => window.print();
})();
