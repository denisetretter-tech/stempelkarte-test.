// dean & david Stempelkarte – Testversion ohne Server. Alle Daten bleiben auf diesem Handy.
(() => {
const $ = s => document.querySelector(s), app = $('#app');
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const R = { goal: 10, half: 5, minBon: 8, windowMin: 120, perDay: 2 };
const STORES = { zwe: 'Zweibrücken', tri: 'Trier' }, REG = { 'AMA-8736': 'zwe', 'AMA-5779': 'tri' };
const REWARDS = ['Bowl', 'Salat', 'Curry'], DAY = 864e5, DN = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
const DAYCOL = [['Beere', '#B85C84', '#fff'], ['Grün', '#6BAB6B', '#fff'], ['Coral', '#ED6954', '#fff'], ['Gelbgrün', '#E8E882', '#3c4a1c'], ['Dunkelgrün', '#4F614F', '#fff'], ['Salbei', '#B5D0AF', '#2f3a2f'], ['Blau', '#5B8DB8', '#fff']];
const STAMP = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11h18a9 9 0 0 1-18 0z" fill="#4F614F"/><path d="M7 8c2-3 8-3 10 0" stroke="#4F614F" stroke-width="2" fill="none" stroke-linecap="round"/></svg>';
const GIFT = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="10" rx="1.5" fill="#4F614F"/><rect x="3" y="7" width="18" height="4" rx="1" fill="#ED6954"/><path d="M12 7v13" stroke="#E8E882" stroke-width="2"/></svg>';
const TOP = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 16.5C6.5 9 12.5 4.8 20 5.5 19 13 12 18.6 4 16.5z" fill="#6BAB6B"/><circle cx="9" cy="13.6" r="2" fill="#4F614F"/><circle cx="12.6" cy="11.2" r="2" fill="#4F614F"/><circle cx="16" cy="8.8" r="1.8" fill="#4F614F"/></svg>';
const KEY = 'dd_stempelkarte_test_v1';
let S = null, mem = null; try { S = JSON.parse(localStorage.getItem(KEY)); } catch (_) {}
let storageOk = true; function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (_) { storageOk = false; } }
let view = 'home', result = null, choice = 'Bowl', kind = 'reward', stream = null, raf = 0, resetArmed = false;
let tt; function toast(m, err) { const t = $('#toast'); t.textContent = m; t.className = 'show' + (err ? ' err' : ''); clearTimeout(tt); tt = setTimeout(() => t.className = err ? 'err' : '', 4000); }
const p2 = n => String(n).padStart(2, '0');
const fmt = ts => { const d = new Date(ts); return `${p2(d.getDate())}.${p2(d.getMonth() + 1)}.${d.getFullYear()}, ${p2(d.getHours())}:${p2(d.getMinutes())} Uhr`; };
const eur = n => n.toFixed(2).replace('.', ',') + ' €';
function parseBon(t) {
  const f = String(t || '').trim().split(';'); if (f.length < 12 || f[0] !== 'V0' || f[2] !== 'Kassenbeleg-V1' || !/^Beleg\^/.test(f[3])) return null;
  const parts = f[3].split('^'); let total = (parts[2] || '').split('_').reduce((a, x) => a + (parseFloat(x.split(':')[0]) || 0), 0);
  if (!total) total = (parts[1] || '').split('_').reduce((a, x) => a + (parseFloat(x) || 0), 0);
  const end = Date.parse(f[7]); if (!f[1] || !f[4] || !Number.isFinite(end)) return null; return { client: f[1].slice(0, 60), txn: f[4].slice(0, 30), end, total };
}
function stopCam() { cancelAnimationFrame(raf); if (stream) stream.getTracks().forEach(t => t.stop()); stream = null; }
function go(v) { stopCam(); view = v; resetArmed = false; render(); window.scrollTo(0, 0); }
function log(text, n) { S.hist.unshift({ text, n, at: Date.now() }); S.hist = S.hist.slice(0, 30); }

function scan(qr) {
  stopCam(); const b = parseBon(qr), now = Date.now(), checks = [];
  if (!b) { result = { pass: false, n: 0, checks: [{ ok: false, t: 'Das ist kein Kassenbon QR Code von dean & david.' }] }; view = 'result'; return render(); }
  const sid = REG[b.client], key = b.client + '#' + b.txn, used = !!S.bons[key], lim = b.end + R.windowMin * 60e3, inTime = (now <= lim && b.end <= now + 6e5) || S.test;
  const today = Object.values(S.bons).filter(at => at > now - DAY).length;
  checks.push({ ok: true, t: sid ? `Kasse erkannt: dean & david ${STORES[sid]}` : `Kasse ${b.client} ist noch nicht hinterlegt. Im Test zählt der Bon trotzdem. Bitte diese Kassen ID an die Zentrale melden.` });
  checks.push({ ok: !used, t: used ? 'Dieser Bon wurde schon gestempelt.' : 'Bon noch nicht verwendet' });
  checks.push({ ok: !!inTime, t: `Gekauft ${fmt(b.end)}` + (inTime ? (S.test && now > lim ? '. Testmodus: Zeitfenster aus.' : '') : '. Scannen geht nur innerhalb von 2 Stunden.') });
  checks.push({ ok: b.total >= R.minBon, t: `Bonsumme ${eur(b.total)}${b.total >= R.minBon ? '' : ', Stempel gibt es ab 8 €'}` });
  if (today >= R.perDay && !S.test) checks.push({ ok: false, t: 'Heute wurden schon 2 Bons gestempelt.' });
  const pass = checks.every(c => c.ok);
  if (pass) { S.bons[key] = now; const before = S.stamps; S.stamps += 1; if (before < R.half && S.stamps >= R.half && !S.topping) S.topping = 1; if (sid) S.store = sid; log('Bon gescannt' + (sid ? ', ' + STORES[sid] : ''), 1); save(); }
  result = { pass, n: pass ? 1 : 0, checks }; view = 'result'; render(); toast(pass ? '+1 Stempel' : 'Kein Stempel für diesen Bon', !pass);
}
function redeem() {
  const sid = $('#rstore').value, d = new Date(), c = DAYCOL[d.getDay()]; let what;
  if (kind === 'topping') { if (S.topping !== 1) return; S.topping = 2; log('Gratis Topping eingelöst, ' + STORES[sid], 0); what = 'Topping'; }
  else { if (S.stamps < R.goal) return; S.stamps -= R.goal; S.topping = S.stamps >= R.half ? 1 : 0; log(choice + ' gratis eingelöst, ' + STORES[sid], -R.goal); what = choice; }
  save(); view = 'home'; render();
  const el = $('#confirm'), start = Date.now(), key = kind === 'topping' ? 'Gratis Topping' : 'Treuekarte', code = String(1000 + Math.floor(Math.random() * 9000));
  el.innerHTML = `<div class="confirm" style="background:${c[1]};color:${c[2]}"><div class="stripes"></div><div class="clock" id="cclock"></div><div>${DN[d.getDay()]} · Tagesfarbe ${c[0]}</div>
  <div class="big">${esc(what)} gratis<br>eingelöst</div><div>${STORES[sid]}</div><div class="code">Kasse: Taste „${key}“ drücken · Code ${code}</div><div id="ccd" style="font-weight:800"></div><button class="pbtn line" id="cdone" style="max-width:220px">Fertig</button></div>`;
  const iv = setInterval(() => { const n = new Date(), left = 60 - Math.floor((Date.now() - start) / 1000); if (!$('#cclock')) return clearInterval(iv);
    $('#cclock').textContent = `${p2(n.getHours())}:${p2(n.getMinutes())}:${p2(n.getSeconds())}`;
    if (left <= 0) { $('#ccd').textContent = 'Abgelaufen. Nicht mehr gültig.'; el.firstChild.classList.add('expired'); } else $('#ccd').textContent = 'Gültig noch ' + left + ' s'; }, 250);
  $('#cdone').onclick = () => { clearInterval(iv); el.innerHTML = ''; };
}
async function startCam() {
  const v = $('#vid'), c = document.createElement('canvas'), x = c.getContext('2d', { willReadFrequently: true });
  try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1280 } }, audio: false }); v.srcObject = stream; await v.play(); }
  catch (_) { const h = $('#camhint'); if (h) h.textContent = 'Die Kamera ist nicht verfügbar. Tippe unten auf „Foto vom Bon wählen“.'; return; }
  const loop = () => { if (view !== 'scan' || !stream) return;
    if (v.videoWidth) { const k = Math.min(1, 900 / v.videoWidth); c.width = v.videoWidth * k; c.height = v.videoHeight * k; x.drawImage(v, 0, 0, c.width, c.height);
      const r = jsQR(x.getImageData(0, 0, c.width, c.height).data, c.width, c.height, { inversionAttempts: 'dontInvert' }); if (r && r.data) return scan(r.data); }
    raf = requestAnimationFrame(loop); }; loop();
}
async function decodeFile(file) {
  const url = URL.createObjectURL(file), img = new Image(); await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
  const c = document.createElement('canvas'), x = c.getContext('2d', { willReadFrequently: true }), W = img.naturalWidth, H = img.naturalHeight;
  for (const size of [1400, 1000, 2000, 700]) for (const [cx, cy, cw, ch] of [[0, 0, 1, 1], [0, .35, 1, .65], [.15, .4, .7, .5], [0, 0, 1, .6]]) {
    const sw = W * cw, sh = H * ch, k = Math.min(1, size / Math.max(sw, sh)); c.width = Math.round(sw * k); c.height = Math.round(sh * k); x.drawImage(img, W * cx, H * cy, sw, sh, 0, 0, c.width, c.height);
    const r = jsQR(x.getImageData(0, 0, c.width, c.height).data, c.width, c.height); if (r && r.data) { URL.revokeObjectURL(url); return r.data; } }
  URL.revokeObjectURL(url); return null;
}
function card() {
  const n = Math.min(S.stamps, R.goal); let s = '';
  for (let i = 0; i < R.goal; i++) { const on = i < n, last = i === R.goal - 1, half = i === R.half - 1; s += `<div class="slot${on ? ' on' : ''}${last ? ' gift' : ''}${half ? ' half' : ''}">${on ? (last ? GIFT : half ? TOP : STAMP) : half ? 'Topping' : ''}</div>`; }
  const rem = R.goal - S.stamps;
  return `<div class="card"><div class="cardhead"><span>Stempelkarte</span><b>${n} / ${R.goal}</b></div><div class="slots">${s}</div><div class="cardfoot">${S.stamps < R.half ? `Noch ${R.half - S.stamps} bis zum Gratis Topping, ${rem} bis zur Gratis Bowl, Salat oder Curry` : rem > 0 ? `Noch ${rem} Stempel bis zu Deiner Gratis Bowl, Salat oder Curry` : 'Deine Prämie ist bereit: Bowl, Salat oder Curry gratis.'}${S.stamps > R.goal ? `<br>+${S.stamps - R.goal} Stempel schon für die nächste Karte` : ''}</div></div>`;
}
function render() {
  $('#hello').textContent = S ? 'Hallo ' + S.name : ''; let h = '';
  if (!S) { const qs = new URLSearchParams(location.search).get('s');
    app.innerHTML = `<h1>Deine <em>Stempelkarte</em></h1><p style="margin:0">10 Stempel sammeln, dann gibt es eine Bowl, einen Salat oder ein Curry gratis. Bei 5 Stempeln ein Basic Topping.</p>
    <div class="field"><label for="name">Dein Vorname</label><input type="text" id="name" maxlength="30" autocomplete="given-name"></div>
    <div class="field"><label for="jstore">Dein Store</label><select id="jstore">${Object.entries(STORES).map(([k, v]) => `<option value="${k}" ${k === qs ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
    <button class="pbtn coral" data-a="join">Stempelkarte starten</button><p class="small">Testversion: Deine Stempel werden nur auf diesem Handy gespeichert. Es ist kein Download und keine Anmeldung nötig.</p>`; return; }
  if (view === 'home') h = card()
    + (S.topping === 1 ? `<div class="halfbox"><span><b>Halbzeit! Ein Basic Topping ist gratis</b><br>Edamame, Röstzwiebeln, Gurke oder Tomate</span><button data-a="topping">An der Kasse</button></div>` : '')
    + `<div class="acts"><button class="abtn prim wide" data-a="scan"><strong>Bon scannen und Stempel sammeln</strong><span>bis 2 Stunden nach dem Kauf, an der Kasse oder am Terminal</span></button>
    <button class="abtn hot wide" data-a="redeem" ${S.stamps < R.goal ? 'disabled' : ''}><strong>Prämie einlösen</strong><span>${S.stamps < R.goal ? 'ab 10 Stempeln' : 'Bowl, Salat oder Curry gratis'}</span></button></div>`
    + (S.hist.length ? '<p class="lh">Verlauf</p><ul class="list">' + S.hist.slice(0, 10).map(x => `<li><span>${esc(x.text)}<small>${fmt(x.at)}</small></span><span class="${x.n < 0 ? 'minus' : 'plus'}">${x.n > 0 ? '+' + x.n : x.n < 0 ? x.n : '✓'}</span></li>`).join('') + '</ul>' : '')
    + '<p class="small">Tipp: Lege diese Seite auf Deinen Startbildschirm. iPhone: Teilen, dann „Zum Home Bildschirm“. Android: Menü, dann „Zum Startbildschirm hinzufügen“.</p>'
    + `<details class="box"><summary>Einstellungen für den Test</summary><label class="chk" for="test"><input type="checkbox" id="test" ${S.test ? 'checked' : ''}><span>Testmodus: Bons auch nach mehr als 2 Stunden und mehr als 2 Bons pro Tag annehmen</span></label>
      <button class="pbtn line" data-a="fill">Test: Karte auf 9 Stempel setzen</button><button class="pbtn line" data-a="reset">${resetArmed ? 'Wirklich löschen? Noch einmal tippen' : 'Karte zurücksetzen'}</button></details>`
    + (storageOk ? '' : '<div class="banner c">Dieses Handy speichert die Karte nicht dauerhaft. Bitte nicht im privaten Modus öffnen.</div>');
  if (view === 'scan') h = `<button class="back" data-a="home">‹ Zurück</button><h2>Bon <em>scannen</em></h2><div class="cam"><video id="vid" playsinline muted></video></div><p class="small" id="camhint">Halte den QR Code unten auf Deinem Bon in den Rahmen.</p>
    <label class="pbtn line" style="text-align:center;display:block">Foto vom Bon wählen<input type="file" id="bonfile" accept="image/*" hidden></label><p class="small">Jeder Bon zählt einmal, ab 8 € Bonsumme, bis 2 Stunden nach dem Kauf.</p>`;
  if (view === 'result') h = `<button class="back" data-a="home">‹ Zur Karte</button><h2>Bon <em>${result.pass ? 'gestempelt' : 'abgelehnt'}</em></h2><div class="resbox ${result.pass ? 'ok' : 'no'}"><b>${result.pass ? '+1 Stempel' : 'Kein Stempel'}</b></div>
    <ul class="checks">${result.checks.map(c => `<li class="${c.ok ? '' : 'no'}"><i>${c.ok ? '✓' : '✕'}</i><span>${esc(c.t)}</span></li>`).join('')}</ul><button class="pbtn" data-a="home">Zur Karte</button><button class="pbtn line" data-a="scan">Weiteren Bon scannen</button>`;
  if (view === 'redeem') { const tp = kind === 'topping';
    h = `<button class="back" data-a="home">‹ Zurück</button><h2>${tp ? 'Topping' : 'Prämie'} <em>einlösen</em></h2>${tp ? '<p class="small">Ein Basic Topping gratis: Edamame, Röstzwiebeln, Gurke oder Tomate.</p>' : REWARDS.map(c => `<button class="choice" aria-pressed="${choice === c}" data-a="choose" data-v="${c}">${c} gratis</button>`).join('')}
    <div class="field"><label for="rstore">Dein Store</label><select id="rstore">${Object.entries(STORES).map(([k, v]) => `<option value="${k}" ${k === S.store ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
    <p class="small">Wische erst an der Kasse, wenn die Mitarbeiterin oder der Mitarbeiter zusieht. ${tp ? '' : 'Danach werden 10 Stempel abgezogen.'}</p>
    <div class="swipe" id="swipe"><div class="fill" id="sfill"></div><span>Zum Einlösen wischen</span><button class="knob" id="knob" aria-label="Zum Einlösen wischen. Enter zum Bestätigen.">›</button></div>`; }
  app.innerHTML = h;
  if (view === 'scan') startCam();
  if (view === 'redeem') { const k = $('#knob'), tr = $('#swipe'), f = $('#sfill'); let x0 = null, max = 0, x = 0, done = false;
    const set = v => { x = v; k.style.transform = `translateX(${v}px)`; f.style.width = (66 + v) + 'px'; }, fire = () => { if (!done) { done = true; redeem(); } };
    k.onpointerdown = e => { x0 = e.clientX - x; max = tr.clientWidth - 66; k.setPointerCapture(e.pointerId); };
    k.onpointermove = e => { if (x0 !== null) set(Math.max(0, Math.min(max, e.clientX - x0))); };
    k.onpointerup = k.onpointercancel = () => { if (x0 === null) return; x0 = null; if (x > max * .9) { set(max); fire(); } else set(0); };
    k.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fire(); } }; }
}
document.addEventListener('click', e => { const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a;
  if (a === 'join') { const name = $('#name').value.replace(/[<>]/g, '').trim().slice(0, 30); if (name.length < 2) return toast('Bitte gib Deinen Vornamen ein.', true);
    S = { name, store: $('#jstore').value, stamps: 0, topping: 0, bons: {}, hist: [], test: false }; save(); history.replaceState(null, '', location.pathname); render(); toast('Willkommen, ' + name + '!'); }
  if (a === 'home' || a === 'scan') go(a);
  if (a === 'redeem' || a === 'topping') { kind = a === 'topping' ? 'topping' : 'reward'; go('redeem'); }
  if (a === 'choose') { choice = b.dataset.v; render(); }
  if (a === 'fill') { S.stamps = 9; if (!S.topping) S.topping = 1; log('Test: Karte auf 9 Stempel gesetzt', 0); save(); render(); window.scrollTo(0, 0); }
  if (a === 'reset') { if (!resetArmed) { resetArmed = true; return render(); } try { localStorage.removeItem(KEY); } catch (_) {} S = null; resetArmed = false; view = 'home'; render(); }
});
document.addEventListener('change', async e => {
  if (e.target.id === 'test') { S.test = e.target.checked; save(); toast(S.test ? 'Testmodus an' : 'Testmodus aus'); }
  if (e.target.id === 'bonfile' && e.target.files[0]) { toast('QR Code wird gelesen'); try { const t = await decodeFile(e.target.files[0]); if (!t) return toast('Kein QR Code erkannt. Bitte den Code groß und scharf fotografieren.', true); scan(t); } catch (_) { toast('Das Bild konnte nicht gelesen werden.', true); } }
});
render();
})();
